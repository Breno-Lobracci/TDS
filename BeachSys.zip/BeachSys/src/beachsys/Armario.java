/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beachsys;

import java.util.ArrayList;

/**
 *
 * @author Breno
 */
public class Armario {
    private String nome;
    private int pontox;
    private int pontoy;
    private Compartimento compartimento;
    private ArrayList<Compartimento> compartimentos;
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPontox() {
        return pontox;
    }

    public void setPontox(int pontox) {
        this.pontox = pontox;
    }

    public int getPontoy() {
        return pontoy;
    }

    public void setPontoy(int pontoy) {
        this.pontoy = pontoy;
    }

    public int getCompartimento() {
        return this.compartimento.getNumero();
    }

    public void setCompartimento(Compartimento compartimento) {
        this.compartimento = compartimento;
    }

    public ArrayList<Compartimento> getCompartimentos() {
        return compartimentos;
    }

    public void setCompartimentos(ArrayList<Compartimento> compartimentos) {
        this.compartimentos = compartimentos;
    }
    
    public int quantidadeCompartimentos(){
        int somatorio = 0;
        for (int i = 0; i < this.compartimentos.size(); i++) {
            somatorio = somatorio + this.compartimentos.get(i).getNumero();
        }
        return somatorio;
    }
    
}
