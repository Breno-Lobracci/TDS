/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beachsys;

/**
 *
 * @author Breno
 */
public class Usuario {
    private String nome;
    private int cpf;
    private String email;
    private Compartimento compartimento;
    private Armario armario;

    public Armario getArmario() {
        return armario;
    }

    public void setArmario(Armario armario) {
        this.armario = armario;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCompartimento() {
        return this.compartimento.getNumero();
    }

    public void setCompartimento(Compartimento compartimento) {
        this.compartimento = compartimento;
    }

    
    
    
    
}
