/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package beachsys;

import java.util.ArrayList;

/**
 *
 * @author Breno
 */
public class BeachSys {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Instaciando Compartimentos
        Compartimento compartimento1 = new Compartimento();
        compartimento1.setNumero(1);
        compartimento1.setTamanho("100x500cm");
        
        Compartimento compartimento2 = new Compartimento();
        compartimento2.setNumero(2);
        compartimento2.setTamanho("120x550cm");
        
        //Instanciando Armarios
        Armario armario = new Armario();
        armario.setNome("Brotas");
        armario.setPontox(2312);
        armario.setPontoy(654654);
        armario.setCompartimento(compartimento2);
        //Instanciando Usuários
        Usuario usuario = new Usuario();
        usuario.setCpf(123456);
        usuario.setEmail("aopsidja@gmail.com");
        usuario.setNome("João");
        usuario.setCompartimento(compartimento2);
        //Criando lista de compartimentos
        ArrayList<Compartimento> compartimentos = new ArrayList<>();
        compartimentos.add(compartimento1);
        compartimentos.add(compartimento2);
        
        System.out.println("Armario:" + armario.getNome() + " Ponto x: " + armario.getPontox() + " Ponto y: " + armario.getPontoy() + " Compartimento : "+ armario.getCompartimento());
        System.out.println("Usuário: "+ usuario.getNome() + " CPF: " + usuario.getCpf() + " Email: " + usuario.getEmail() + " Compartimento: " + usuario.getCompartimento());
        for (int i = 0; i < compartimentos.size(); i++) {
            System.out.println("Tamanho: " + compartimentos.size());
        }
    }
    
}
