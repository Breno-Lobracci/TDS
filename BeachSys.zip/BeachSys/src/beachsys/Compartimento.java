/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beachsys;

/**
 *
 * @author Breno
 */
public class Compartimento {
    private int numero;
    private String tamanho;
    private boolean statusDisponivel;
    private boolean statusOcupado;

    public boolean isStatusDisponivel() {
        statusDisponivel = true;
        return statusDisponivel;
    }

    public boolean isStatusOcupado() {
        statusOcupado = false;
        return statusOcupado;
    }
    
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }
    
    
}
